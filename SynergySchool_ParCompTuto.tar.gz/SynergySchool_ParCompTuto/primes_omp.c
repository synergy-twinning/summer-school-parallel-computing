#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

int isPrime(const int i){
    for(int j=2; j<i-1; j++)
        if(i%j==0)return 0;

    return 1;
}

int main(int argc,char** argv)
{
    double start;

    int n=100000;

    if(argc>1)n = atoi(argv[1]);

    int count_prime=0;

#pragma omp parallel private(start)
{
    start=omp_get_wtime();

    #pragma omp for
    for (int i = 2; i < n; i++) {
        count_prime+=isPrime(i);//returns 1 if i is prime
    }
    printf("thread %d :\t %f\n",omp_get_thread_num(),omp_get_wtime()-start);

    #pragma omp barrier
    if(omp_get_thread_num()==0){
        printf("\ntime :\t %f\n",omp_get_wtime()-start);
    }
}

    printf("number of primes in [2,%d]:\t %d\n",n,count_prime);
}
