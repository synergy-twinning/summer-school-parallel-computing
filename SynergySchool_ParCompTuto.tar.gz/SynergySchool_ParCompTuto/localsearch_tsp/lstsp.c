#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#include "aux.h"

int main(int argc, char **argv)
{
    if (argc > 1) initFromFile(argv[1]);
    else printf("need .tsp input file as argument");

    // initial tour
    int *tour;
    tour    = (int *)malloc((N + 1) * sizeof(int));
    tour[0] = 0; // start

    for (int i = 1; i < N; ++i) tour[i] = i;
    tour[N] = 0; // arrival
    // randomizeTour(tour, time(NULL));

    printf("initial cost: %f\n =====================\n", eval(tour));

    struct timespec tstart, tend;
    clock_gettime(CLOCK_MONOTONIC, &tstart);

    Move best_move = { 0, 0 };
    int  iter      = 0;

    for (;;) {
        double delta_max = 0.0f;

        // find best move...
        for (int i = 1; i < N - 1; ++i) {
            for (int j = i + 1; j < N; ++j) {
                Move   mv    = { i, j };
                double delta = eval2opt(tour, mv); // mv improves tour by delta

                if (delta > delta_max) {
                    delta_max = delta;
                    best_move = mv;
                }

                // printf("DELTA %f\n",delta);
            }
        }

        // stuck in local opt or iteration limit reached? STOP
        if ((delta_max < 1e-7) || (iter > 10000)) break;

        // apply best move
        apply2opt(tour, best_move);

        // printf("delta %lf\n",delta_max);//,bestcost);
        iter++;
    } // for(;;)

    //    for(int i=0;i<N;++i)printf("%3d ",tour[i]);
    //    printf("\n\n");

    clock_gettime(CLOCK_MONOTONIC, &tend);

    printf("\n =========== \nfinal cost: %f\n", eval(tour));
    printf("iterations: %d\n",                  iter);
    printf("search time (sec): %5.5f\n",
           (tend.tv_sec - tstart.tv_sec) + (tend.tv_nsec - tstart.tv_nsec) / 1e9);

    free(tour);
    free(xcoord);
    free(ycoord);

    return 0;
}
