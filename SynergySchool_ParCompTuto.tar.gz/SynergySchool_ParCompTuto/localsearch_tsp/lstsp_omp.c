#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <omp.h>

#include "aux.h"

int main(int argc, char **argv)
{
    if (argc > 1) initFromFile(argv[1]);
    else printf("need .tsp input file as argument");

    // initial tour
    int *tour;
    tour    = (int *)malloc((N + 1) * sizeof(int));
    tour[0] = 0; // start city fixed at 0

    for (int i = 1; i < N; ++i) tour[i] = i;
    tour[N] = 0; // arrival
    // randomizeTour(tour, time(NULL));

    printf("initial cost: %f\n =====================\n", eval(tour));

    struct timespec tstart, tend;
    clock_gettime(CLOCK_MONOTONIC, &tstart);

    int  iter      = 0;

    //pairs contains all possible city pairs 0<i<j<N
    int  nbmoves = (N - 1) * (N - 2) / 2;
    int *pairs[2];
    pairs[0] = (int *)malloc(nbmoves * sizeof(int));
    pairs[1] = (int *)malloc(nbmoves * sizeof(int));

    int c = 0;

    for (int i = 1; i + 2 <= N; ++i) {
        for (int j = i + 1; j < N; ++j) {
            pairs[0][c] = i;
            pairs[1][c] = j;
            c++;
        }
    }
    //==========

    //data for thread-wise storage of max_delta and ID of best move
    int nb_threads=1;
#pragma omp parallel
    nb_threads = omp_get_num_threads();

    double *max_deltas;
    max_deltas = (double *)malloc(nb_threads * sizeof(double));
    int *best_move_ids;
    best_move_ids = (int *)malloc(nb_threads * sizeof(int));
    //==========

    //thread private...
    double delta_max;
    int    id_best;

    for (;;) {
#pragma omp parallel private(delta_max, id_best)
        {
            delta_max = 0.0f;
            id_best   = 0;

            // find best move...
#pragma omp for
            for (int k = 0; k < nbmoves; ++k) {
                Move   mv    = { pairs[0][k], pairs[1][k] };
                double delta = eval2opt(tour, mv); // mv improves tour by delta

                if (delta > delta_max) {
                    delta_max = delta;
                    id_best   = k;
                }
            }
            max_deltas[omp_get_thread_num()]    = delta_max;
            best_move_ids[omp_get_thread_num()] = id_best;
        } // omp parallel

        double global_delta_max    = 0.0;
        int    global_best_move_id = 0;

        for (int i = 0; i < nb_threads; i++) {
            if (max_deltas[i] > global_delta_max) {
                global_delta_max    = max_deltas[i];
                global_best_move_id = best_move_ids[i];
            }
        }

        // stuck in local opt or iteration limit reached? STOP
        if ((global_delta_max < 1e-7) || (iter > 10000)) break;//break must be outside parallel region!!

        // apply best move
        Move global_best_move = { pairs[0][global_best_move_id],
                                  pairs[1][global_best_move_id] };
        apply2opt(tour, global_best_move);

//        printf("delta %lf\n", global_delta_max); // ,bestcost);
        iter++;
    } 

    //    for(int i=0;i<N;++i)printf("%3d ",tour[i]);
    //    printf("\n\n");

    clock_gettime(CLOCK_MONOTONIC, &tend);

    printf("\n =========== \nfinal cost: %f\n", eval(tour));
    printf("iterations: %d\n",                  iter);
    printf("search time (sec): %5.5f\n",
           (tend.tv_sec - tstart.tv_sec) + (tend.tv_nsec - tstart.tv_nsec) / 1e9);

    free(pairs[0]);
    free(pairs[1]);
    free(tour);
    free(xcoord);
    free(ycoord);
    free(max_deltas);
    free(best_move_ids);

    return 0;
}
