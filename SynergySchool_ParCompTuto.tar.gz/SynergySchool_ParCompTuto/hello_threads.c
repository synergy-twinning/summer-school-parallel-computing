#include <stdio.h>
#include <omp.h>

int main()
{
    int thread_id=0;
    int threads_num=1;
    printf("only one thread.\n");

    #pragma omp parallel private(thread_id,threads_num)
    {
        #ifdef _OPENMP
        thread_id = omp_get_thread_num();
        threads_num = omp_get_num_threads();
        #endif
        printf("hello from thread %d of %d\n",thread_id,threads_num);
    }

    printf("back to one thread.\n");
}
