#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

int isPrime(const int i){
    for(int j=2; j<i-1; j++)
        if(i%j==0)return 0;

    return 1;
}

int main(int argc,char** argv)
{
    int n=100000;

    if(argc>1)n = atoi(argv[1]);

    int count_prime=0;

    for (int i = 2; i < n; i++) {
        count_prime+=isPrime(i);
    }

    printf("number of primes in [2,%d]:\t %d\n",n,count_prime);
}
